# Floating cat

A cat that float and spin around your web browser :> <br>
This extension is completely safe. There is no virus or malware. There is no information collecting so don't worry <br>
The extension is still in development and there will be more feature :)